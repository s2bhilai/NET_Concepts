﻿namespace PublisherDomain
{
    public class AuthorByArtist
    {
        public string Artist { get; set; }
        public string? Author { get; set; }
    }
}
