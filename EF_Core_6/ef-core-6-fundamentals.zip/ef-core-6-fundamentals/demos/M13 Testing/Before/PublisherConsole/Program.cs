﻿using Microsoft.EntityFrameworkCore;
using PublisherData;

PubContext _context = new PubContext(); //existing database

