﻿//example class for mapping skip nav with payload
//namespace PublisherDomain 
//{
//    public class CoverAssignment
//    {
//        public int ArtistId { get; set; }
//        public int CoverId { get; set; }
//        public DateTime DateCreated { get; set; }
//    }
//}
