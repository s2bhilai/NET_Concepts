# Pluralsight EF Core 6 Fundamentals  
All code samples for EF Core 6 Fundamentals on Pluralsight  
Published April 2022  
https://bit.ly/EFCore6

Samples are organized by module with before and after versions. The last 3 modules (14, 15, 16) don't have before and after. They just have solutions that were discussed in those modules.

Demos are alo available on GitHub at https://github.com/julielerman/PluralsightEFCore6Fundamentals

