﻿namespace EmployeeManagement.Models
{
    public class PromotionForCreationDto
    {
        public Guid EmployeeId { get; set; }

    }
}
