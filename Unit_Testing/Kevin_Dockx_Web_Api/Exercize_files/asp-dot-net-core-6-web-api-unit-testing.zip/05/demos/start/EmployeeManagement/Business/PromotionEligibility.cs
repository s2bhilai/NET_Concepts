﻿namespace EmployeeManagement.Business
{
    public class PromotionEligibility
    {
        public bool EligibleForPromotion { get; set; }
    }
}
