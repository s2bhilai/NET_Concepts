﻿namespace EmployeeManagement.Models
{
    public class PromotionResultDto
    {
        public Guid EmployeeId { get; set; }
        public int JobLevel { get; set; }
    }
}
